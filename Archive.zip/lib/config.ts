/** WHY: Central toggle. DB reads are disabled by default. */
export const ENABLE_DB = process.env.ENABLE_DB === "true";
