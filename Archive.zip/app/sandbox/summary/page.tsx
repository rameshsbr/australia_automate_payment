export { default } from "@/app/(app)/summary/page";
