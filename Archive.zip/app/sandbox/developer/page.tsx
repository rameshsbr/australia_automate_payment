export { default } from "@/app/(app)/developer/page";
