export { default } from "@/app/(app)/foreign-exchange/page";
