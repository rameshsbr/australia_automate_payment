export { default } from "@/app/(app)/payments/returned/page";
