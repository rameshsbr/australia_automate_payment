export { default } from "@/app/(app)/payments/rtgs-imt/page";
