export { default } from "@/app/(app)/payments/batch/page";
