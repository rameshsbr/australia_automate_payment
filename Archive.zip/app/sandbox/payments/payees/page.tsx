export { default } from "@/app/(app)/payments/payees/page";
