export { default } from "@/app/(app)/payments/card/page";
