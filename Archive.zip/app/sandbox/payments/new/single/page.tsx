export { default } from "@/app/(app)/payments/new/single/page";
