export { default } from "@/app/(app)/payments/new/batch/page";
