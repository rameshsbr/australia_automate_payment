export { default } from "@/app/(app)/payments/new/simulate/page";
