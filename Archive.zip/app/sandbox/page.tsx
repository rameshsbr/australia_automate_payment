import { redirect } from "next/navigation";

export default function SandboxIndex() {
  redirect("/sandbox/summary");
}
