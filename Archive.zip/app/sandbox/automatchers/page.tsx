export { default } from "@/app/(app)/automatchers/page";
