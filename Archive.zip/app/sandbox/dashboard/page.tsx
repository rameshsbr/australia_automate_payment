export { default } from "@/app/(app)/dashboard/page";
