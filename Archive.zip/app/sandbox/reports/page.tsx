export { default } from "@/app/(app)/reports/page";
