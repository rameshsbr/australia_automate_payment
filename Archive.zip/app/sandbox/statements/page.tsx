export { default } from "@/app/(app)/statements/page";
